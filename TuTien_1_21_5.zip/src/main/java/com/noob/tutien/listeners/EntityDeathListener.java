package com.noob.tutien.listeners;

import com.noob.tutien.TuTienPlugin;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

import java.util.concurrent.ThreadLocalRandom;

public class EntityDeathListener implements Listener {
    private final TuTienPlugin plugin;
    public EntityDeathListener(TuTienPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent e) {
        Entity dead = e.getEntity();
        if (dead.getKiller() == null) return;
        Player killer = dead.getKiller();
        // If killer is Tu Tien, gain 2-10
        String tuhanh = plugin.getDataManager().getTuhanh(killer.getUniqueId());
        if ("tien".equalsIgnoreCase(tuhanh)) {
            int gain = ThreadLocalRandom.current().nextInt(2, 11);
            plugin.getDataManager().addLinhKhi(killer.getUniqueId(), gain);
            killer.sendMessage("§aBạn nhận được §e" + gain + " §aling khí khi giết quái.");
        } else if ("ma".equalsIgnoreCase(tuhanh)) {
            // Ma Tu: absorb from victim; if victim is player, steal random portion
            if (dead instanceof Player) {
                Player vic = (Player) dead;
                int vicLk = plugin.getDataManager().getLinhKhi(vic.getUniqueId());
                int steal = Math.min(vicLk, ThreadLocalRandom.current().nextInt(1, Math.max(2, vicLk+1)));
                plugin.getDataManager().addLinhKhi(killer.getUniqueId(), steal);
                plugin.getDataManager().setLinhKhi(vic.getUniqueId(), Math.max(0, vicLk - steal));
                killer.sendMessage("§aBạn hấp thụ §e" + steal + " §aling khí từ " + vic.getName());
            } else {
                int gain = ThreadLocalRandom.current().nextInt(1, 6);
                plugin.getDataManager().addLinhKhi(killer.getUniqueId(), gain);
                killer.sendMessage("§aBạn hấp thụ §e" + gain + " §aling khí khi giết quái.");
            }
        }
    }
}
