package com.noob.tutien.listeners;

import com.noob.tutien.TuTienPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerToggleSneakEvent;

import java.util.UUID;

public class SneakListener implements Listener {
    private final TuTienPlugin plugin;
    public SneakListener(TuTienPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (e.isSneaking()) {
            UUID id = e.getPlayer().getUniqueId();
            if (plugin.getMeditationManager().isMeditating(id)) {
                plugin.getMeditationManager().stopMeditation(id, true);
            }
        }
    }
}
