package com.noob.tutien;

import com.noob.tutien.commands.AdminCommand;
import com.noob.tutien.commands.DotPhaCommand;
import com.noob.tutien.commands.LinhKhiCommand;
import com.noob.tutien.commands.NhanVatCommand;
import com.noob.tutien.commands.TuHanhCommand;
import com.noob.tutien.commands.TuLuyenCommand;
import com.noob.tutien.listeners.EntityDeathListener;
import com.noob.tutien.listeners.SneakListener;
import com.noob.tutien.managers.DataManager;
import com.noob.tutien.managers.MeditationManager;
import com.noob.tutien.managers.RealmManager;
import org.bukkit.plugin.java.JavaPlugin;

public class TuTienPlugin extends JavaPlugin {

    private static TuTienPlugin instance;
    private DataManager dataManager;
    private MeditationManager meditationManager;
    private RealmManager realmManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        dataManager = new DataManager(this);
        realmManager = new RealmManager(this);
        meditationManager = new MeditationManager(this);

        // Commands
        getCommand("tuhanh").setExecutor(new TuHanhCommand(this));
        getCommand("tuluyen").setExecutor(new TuLuyenCommand(this));
        getCommand("linhkhi").setExecutor(new LinhKhiCommand(this));
        getCommand("dotpha").setExecutor(new DotPhaCommand(this));
        getCommand("nhanvat").setExecutor(new NhanVatCommand(this));
        getCommand("tutienadmin").setExecutor(new AdminCommand(this));

        // Events
        getServer().getPluginManager().registerEvents(new SneakListener(this), this);
        getServer().getPluginManager().registerEvents(new EntityDeathListener(this), this);

        getLogger().info("TuTien enabled");
    }

    @Override
    public void onDisable() {
        meditationManager.stopAll();
        saveConfig();
        getLogger().info("TuTien disabled");
    }

    public static TuTienPlugin getInstance() {
        return instance;
    }

    public DataManager getDataManager() {
        return dataManager;
    }

    public MeditationManager getMeditationManager() {
        return meditationManager;
    }

    public RealmManager getRealmManager() {
        return realmManager;
    }
}
