package com.noob.tutien.commands;

import com.noob.tutien.TuTienPlugin;
import com.noob.tutien.managers.RealmManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Random;

public class DotPhaCommand implements CommandExecutor {
    private final TuTienPlugin plugin;
    private final Random rnd = new Random();
    public DotPhaCommand(TuTienPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(\"Chỉ người chơi mới dùng lệnh này.\");
            return true;
        }
        Player p = (Player) sender;
        // require /sit - we can't check GSit here; we'll assume player must be sneaking as simplification
        if (!p.isSneaking()) {
            p.sendMessage(\"§cBạn phải ngồi (sử dụng /sit hoặc tương tự) để đột phá.\");
            return true;
        }
        String current = plugin.getDataManager().getRealm(p.getUniqueId());
        RealmManager.RealmInfo next = plugin.getRealmManager().getNextRealm(current);
        if (next == null) {
            p.sendMessage(\"§cKhông tìm được cảnh giới tiếp theo.\");
            return true;
        }
        int playerLk = plugin.getDataManager().getLinhKhi(p.getUniqueId());
        if (playerLk < next.requirement) {
            p.sendMessage(\"§cBạn cần §e\" + next.requirement + \" §clinh khí để đột phá.\"); 
            return true;
        }
        p.sendMessage(\"§aBắt đầu đột phá sang: §e\" + next.name);
        // strike lightning repeatedly for dramatic effect; schedule a few strikes
        Location loc = p.getLocation();
        for (int i=0;i<5;i++) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> loc.getWorld().strikeLightning(loc), i*10L);
        }
        // determine success
        double chance = next.successRate;
        boolean success = rnd.nextDouble() <= chance;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (success) {
                plugin.getDataManager().setRealm(p.getUniqueId(), next.name);
                Bukkit.broadcastMessage(\"§b[TuTien] §e\" + p.getName() + \" đã đột phá thành công sang: \" + next.name);
            } else {
                // fail: die by lightning and lose random LK
                int lose = Math.max(1, rnd.nextInt(playerLk+1));
                plugin.getDataManager().setLinhKhi(p.getUniqueId(), Math.max(0, playerLk - lose));
                p.setHealth(0.0);
                p.sendMessage(\"§cĐột phá thất bại! Bạn mất §e\" + lose + \" §clinh khí và bị sét đánh.\"); 
            }
        }, 60L);
        return true;
    }
}
