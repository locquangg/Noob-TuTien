package com.noob.tutien.commands;

import com.noob.tutien.TuTienPlugin;
import com.noob.tutien.managers.DataManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class TuHanhCommand implements CommandExecutor {
    private final TuTienPlugin plugin;
    public TuHanhCommand(TuTienPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Chỉ người chơi mới dùng lệnh này.");
            return true;
        }
        Player p = (Player) sender;
        UUID id = p.getUniqueId();
        if (args.length < 1) {
            p.sendMessage("Sử dụng: /tuhanh <tien|ma>");
            return true;
        }
        String choice = args[0].toLowerCase();
        DataManager dm = plugin.getDataManager();
        if (dm.getTuhanh(id) != null) {
            p.sendMessage("§cBạn đã chọn hướng tu hành rồi. Không thể đổi.");
            return true;
        }
        if (!choice.equals("tien") && !choice.equals("ma")) {
            p.sendMessage("§cLựa chọn không hợp lệ.");
            return true;
        }
        dm.setTuhanh(id, choice);
        p.sendMessage(\"§aBạn đã chọn hướng tu hành: §e\" + (choice.equals(\"tien\")?\"Tu Tiên\":\"Ma Tu\"));
        return true;
    }
}
