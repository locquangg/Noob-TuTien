package com.noob.tutien.commands;

import com.noob.tutien.TuTienPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NhanVatCommand implements CommandExecutor {
    private final TuTienPlugin plugin;
    public NhanVatCommand(TuTienPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Chỉ người chơi mới dùng lệnh này.");
            return true;
        }
        Player p = (Player) sender;
        String tuhanh = plugin.getDataManager().getTuhanh(p.getUniqueId());
        if (tuhanh == null) tuhanh = "Chưa chọn";
        String realm = plugin.getDataManager().getRealm(p.getUniqueId());
        int lk = plugin.getDataManager().getLinhKhi(p.getUniqueId());
        p.sendMessage(\"§a--- Thông tin nhân vật ---\");
        p.sendMessage(\"§6Tên: §e\" + p.getName());
        p.sendMessage(\"§6Hướng tu hành: §e\" + tuhanh);
        p.sendMessage(\"§6Cảnh giới: §e\" + realm);
        p.sendMessage(\"§6Linh khí: §e\" + lk);
        return true;
    }
}
