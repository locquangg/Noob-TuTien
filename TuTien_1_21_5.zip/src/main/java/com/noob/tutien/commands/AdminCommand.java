package com.noob.tutien.commands;

import com.noob.tutien.TuTienPlugin;
import com.noob.tutien.managers.DataManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import org.bukkit.entity.Player;

import java.util.UUID;

public class AdminCommand implements CommandExecutor {
    private final TuTienPlugin plugin;
    public AdminCommand(TuTienPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("tutien.admin")) {
            sender.sendMessage("§cBạn không có quyền.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage("§cSử dụng: /tutienadmin <subcommand>");
            return true;
        }
        DataManager dm = plugin.getDataManager();
        String sub = args[0].toLowerCase();
        try {
            switch (sub) {
                case "lk":
                    if (args.length<2) { sender.sendMessage("Usage: /tutienadmin lk <player>"); return true; }
                    Player t = Bukkit.getPlayer(args[1]); if (t==null){ sender.sendMessage("Player offline"); return true; }
                    sender.sendMessage("Linh khí của " + t.getName() + ": " + dm.getLinhKhi(t.getUniqueId()));
                    break;
                case "setlk":
                    if (args.length<3) { sender.sendMessage("Usage: /tutienadmin setlk <player> <số>"); return true; }
                    Player s = Bukkit.getPlayer(args[1]); if (s==null){ sender.sendMessage("Player offline"); return true; }
                    int v = Integer.parseInt(args[2]);
                    dm.setLinhKhi(s.getUniqueId(), v);
                    sender.sendMessage("Đã đặt linh khí cho " + s.getName());
                    break;
                case "addlk":
                    if (args.length<3) { sender.sendMessage("Usage: /tutienadmin addlk <player> <số>"); return true; }
                    Player a = Bukkit.getPlayer(args[1]); if (a==null){ sender.sendMessage("Player offline"); return true; }
                    int va = Integer.parseInt(args[2]);
                    dm.addLinhKhi(a.getUniqueId(), va);
                    sender.sendMessage("Đã cộng linh khí cho " + a.getName());
                    break;
                case "takelk":
                    if (args.length<3) { sender.sendMessage("Usage: /tutienadmin takelk <player> <số>"); return true; }
                    Player tk = Bukkit.getPlayer(args[1]); if (tk==null){ sender.sendMessage("Player offline"); return true; }
                    int vt = Integer.parseInt(args[2]);
                    dm.setLinhKhi(tk.getUniqueId(), Math.max(0, dm.getLinhKhi(tk.getUniqueId()) - vt));
                    sender.sendMessage("Đã trừ linh khí cho " + tk.getName());
                    break;
                case "setcanhgioi":
                    if (args.length<3) { sender.sendMessage("Usage: /tutienadmin setcanhgioi <player> <cảnh giới>"); return true; }
                    Player sc = Bukkit.getPlayer(args[1]); if (sc==null){ sender.sendMessage("Player offline"); return true; }
                    String realm = args[2];
                    dm.setRealm(sc.getUniqueId(), realm);
                    sender.sendMessage("Đã đặt cảnh giới cho " + sc.getName());
                    break;
                case "reset":
                    if (args.length<2) { sender.sendMessage("Usage: /tutienadmin reset <player>"); return true; }
                    Player r = Bukkit.getPlayer(args[1]); if (r==null){ sender.sendMessage("Player offline"); return true; }
                    dm.resetPlayer(r.getUniqueId());
                    sender.sendMessage("Đã reset dữ liệu của " + r.getName());
                    break;
                case "canhgioi":
                    sender.sendMessage("Danh sách cảnh giới:");
                    for (String c : plugin.getRealmManager().getRealmList()) sender.sendMessage(" - " + c);
                    break;
                case "checkcanhgioi":
                    if (args.length<2) { sender.sendMessage("Usage: /tutienadmin checkcanhgioi <player>"); return true; }
                    Player cc = Bukkit.getPlayer(args[1]); if (cc==null){ sender.sendMessage("Player offline"); return true; }
                    sender.sendMessage("Cảnh giới " + cc.getName() + ": " + dm.getRealm(cc.getUniqueId()));
                    break;
                case "settuhanh":
                    if (args.length<3) { sender.sendMessage("Usage: /tutienadmin settuhanh <tien/ma> <player>"); return true; }
                    String hh = args[1].toLowerCase();
                    Player pt = Bukkit.getPlayer(args[2]); if (pt==null){ sender.sendMessage("Player offline"); return true; }
                    dm.setTuhanh(pt.getUniqueId(), hh);
                    sender.sendMessage("Đã đặt hướng tu hành cho " + pt.getName());
                    break;
                case "checktuhanh":
                    if (args.length<2) { sender.sendMessage("Usage: /tutienadmin checktuhanh <player>"); return true; }
                    Player ct = Bukkit.getPlayer(args[1]); if (ct==null){ sender.sendMessage("Player offline"); return true; }
                    sender.sendMessage("Hướng tu hành " + ct.getName() + ": " + dm.getTuhanh(ct.getUniqueId()));
                    break;
                default:
                    sender.sendMessage("Subcommand không hợp lệ.");
            }
        } catch (Exception ex) {
            sender.sendMessage("Lỗi: " + ex.getMessage());
            ex.printStackTrace();
        }
        return true;
    }
}
