package com.noob.tutien.commands;

import com.noob.tutien.TuTienPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LinhKhiCommand implements CommandExecutor {
    private final TuTienPlugin plugin;
    public LinhKhiCommand(TuTienPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Chỉ người chơi mới dùng lệnh này.");
            return true;
        }
        Player p = (Player) sender;
        int lk = plugin.getDataManager().getLinhKhi(p.getUniqueId());
        p.sendMessage(\"§6Linh khí: §e\" + lk);
        return true;
    }
}
