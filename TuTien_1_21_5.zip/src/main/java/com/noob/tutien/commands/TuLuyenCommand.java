package com.noob.tutien.commands;

import com.noob.tutien.TuTienPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TuLuyenCommand implements CommandExecutor {
    private final TuTienPlugin plugin;
    public TuLuyenCommand(TuTienPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Chỉ người chơi mới dùng lệnh này.");
            return true;
        }
        Player p = (Player) sender;
        plugin.getMeditationManager().startMeditation(p);
        return true;
    }
}
