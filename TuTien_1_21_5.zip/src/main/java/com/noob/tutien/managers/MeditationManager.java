package com.noob.tutien.managers;

import com.noob.tutien.TuTienPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class MeditationManager {
    private final TuTienPlugin plugin;
    private final Set<UUID> meditating = new HashSet<>();
    private final Map<UUID, BukkitTask> tasks = new HashMap<>();

    public MeditationManager(TuTienPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isMeditating(UUID uuid) {
        return meditating.contains(uuid);
    }

    public void startMeditation(Player player) {
        UUID id = player.getUniqueId();
        String tuhanh = plugin.getDataManager().getTuhanh(id);
        if (tuhanh == null || !tuhanh.equalsIgnoreCase("tien")) {
            player.sendMessage("§cChỉ có hướng Tu Tiên mới có thể /tuluyen.");
            return;
        }
        if (meditating.contains(id)) {
            player.sendMessage("§eBạn đang tu luyện rồi.");
            return;
        }
        meditating.add(id);
        BukkitTask t = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!player.isOnline()) {
                stopMeditation(id, false);
                return;
            }
            if (!meditating.contains(id)) return;
            int gain = ThreadLocalRandom.current().nextInt(1, 11);
            plugin.getDataManager().addLinhKhi(id, gain);
            // send action bar (use simple message as fallback)
            player.sendActionBar(org.bukkit.TextComponent.text(\"+\"+gain+\" linh khí\"));
            // If enough for next realm, auto-stop (simple check)
            String currentRealm = plugin.getDataManager().getRealm(id);
            RealmManager.RealmInfo next = plugin.getRealmManager().getNextRealm(currentRealm);
            if (next != null && plugin.getDataManager().getLinhKhi(id) >= next.requirement) {
                stopMeditation(id, true);
                player.sendMessage(\"§aBạn đã đủ linh khí để đột phá sang: §e\" + next.name);
            }
        }, 0L, 20L*5);
        tasks.put(id, t);
        player.sendMessage(\"§aBắt đầu tu luyện. Nhấn Shift để dừng.\");
    }

    public void stopMeditation(UUID id, boolean notify) {
        meditating.remove(id);
        BukkitTask t = tasks.remove(id);
        if (t != null) t.cancel();
        if (notify) {
            org.bukkit.entity.Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline()) p.sendMessage(\"§cBạn đã dừng tu luyện.\");
        }
    }

    public void stopAll() {
        for (BukkitTask t : tasks.values()) if (t != null) t.cancel();
        tasks.clear();
        meditating.clear();
    }
}
