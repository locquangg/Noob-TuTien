package com.noob.tutien.managers;

import com.noob.tutien.TuTienPlugin;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.UUID;

public class DataManager {
    private final TuTienPlugin plugin;
    private final FileConfiguration cfg;

    public DataManager(TuTienPlugin plugin) {
        this.plugin = plugin;
        this.cfg = plugin.getConfig();
        // ensure players section exists
        if (cfg.getConfigurationSection("players") == null) {
            cfg.set("players", null);
            plugin.saveConfig();
        }
    }

    public void setTuhanh(UUID uuid, String tuhanh) {
        if (getTuhanh(uuid) != null) return; // only set once
        cfg.set("players." + uuid + ".tuhanh", tuhanh);
        plugin.saveConfig();
    }

    public String getTuhanh(UUID uuid) {
        return cfg.getString("players." + uuid + ".tuhanh", null);
    }

    public int getLinhKhi(UUID uuid) {
        return cfg.getInt("players." + uuid + ".linhkhi", 0);
    }

    public void setLinhKhi(UUID uuid, int amount) {
        cfg.set("players." + uuid + ".linhkhi", Math.max(0, amount));
        plugin.saveConfig();
    }

    public void addLinhKhi(UUID uuid, int amount) {
        setLinhKhi(uuid, getLinhKhi(uuid) + amount);
    }

    public String getRealm(UUID uuid) {
        return cfg.getString("players." + uuid + ".realm", "Phàm Nhân");
    }

    public void setRealm(UUID uuid, String realm) {
        cfg.set("players." + uuid + ".realm", realm);
        plugin.saveConfig();
    }

    public void resetPlayer(UUID uuid) {
        cfg.set("players." + uuid.toString(), null);
        plugin.saveConfig();
    }
}
