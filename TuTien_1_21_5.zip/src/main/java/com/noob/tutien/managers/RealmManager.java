package com.noob.tutien.managers;

import com.noob.tutien.TuTienPlugin;

import java.util.*;

public class RealmManager {
    private final TuTienPlugin plugin;
    private final Map<String, RealmInfo> realms = new LinkedHashMap<>();

    public static class RealmInfo {
        public final String name;
        public final long requirement; // linh khí required
        public final double successRate; // 0-1
        public RealmInfo(String name, long req, double rate) {
            this.name = name; this.requirement = req; this.successRate = rate;
        }
    }

    public RealmManager(TuTienPlugin plugin) {
        this.plugin = plugin;
        loadDefaultRealms();
    }

    private void loadDefaultRealms() {
        // Tu Tien progression (simplified numeric requirements)
        realms.put("Phàm Nhân", new RealmInfo("Phàm Nhân", 0, 1.0));
        realms.put("Luyện Khí 1", new RealmInfo("Luyện Khí 1", 500, 0.95));
        realms.put("Luyện Khí 2", new RealmInfo("Luyện Khí 2", 800, 0.93));
        realms.put("Luyện Khí 3", new RealmInfo("Luyện Khí 3", 1200, 0.9));
        // ... (you can expand to full table later)
        realms.put("Trúc Cơ 1", new RealmInfo("Trúc Cơ 1", 2000, 0.8));
        realms.put("Kết Đan 1", new RealmInfo("Kết Đan 1", 8000, 0.6));
        realms.put("Phi Thăng", new RealmInfo("Phi Thăng", 2000000, 0.01));
    }

    public List<String> getRealmList() {
        return new ArrayList<>(realms.keySet());
    }

    public RealmInfo getNextRealm(String current) {
        List<String> keys = new ArrayList<>(realms.keySet());
        int idx = keys.indexOf(current);
        if (idx == -1) return realms.get(keys.get(0));
        if (idx + 1 >= keys.size()) return realms.get(keys.get(keys.size()-1));
        return realms.get(keys.get(idx+1));
    }

    public RealmInfo getRealm(String name) {
        return realms.get(name);
    }
}
