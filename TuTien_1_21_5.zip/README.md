TuTien - Paper 1.21.5 plugin (Tu Tiên / Ma Tu)
Build with: Java 17 + Maven
How to build:
  mvn package
Jar will be in target/ after successful build.
